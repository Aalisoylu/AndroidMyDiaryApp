package com.example.mydiaryproject

import android.os.AsyncTask
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.View
import com.example.mydiaryproject.databinding.ActivityAddDiaryBinding
import com.example.mydiaryproject.db.DiariesDatabase
import com.example.mydiaryproject.db.entity.DiaryDb
import java.util.*

class AddDiaryActivity : AppCompatActivity() {

    private lateinit var binding: ActivityAddDiaryBinding
    private lateinit var diariesDatabase: DiariesDatabase

    var imageUrl = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add_diary)
        diariesDatabase = DiariesDatabase.invoke(applicationContext)
        binding = ActivityAddDiaryBinding.inflate(layoutInflater)

    }

    fun onClick(view: View) {
        val title: String = (binding.name.text ?: "") as String
        val pass: String = (binding.password.text ?: "") as String
        val desc: String = (binding.description.text ?: "") as String

        AsyncTask.execute {
            diariesDatabase.dairyDao().insertDiary(
                DiaryDb( Calendar.getInstance().time.toString(), title,"", pass, desc, "BAD")
            )
        }
        Log.d("TAG", "onCreate: ")
    }
}