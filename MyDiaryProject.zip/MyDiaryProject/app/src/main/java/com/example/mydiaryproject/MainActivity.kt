package com.example.mydiaryproject

import android.content.Intent
import android.os.AsyncTask
import android.os.Bundle
import android.util.Log
import androidx.appcompat.app.AppCompatActivity
import com.example.mydiaryproject.adapter.DiariesAdapter
import com.example.mydiaryproject.databinding.ActivityMainBinding
import com.example.mydiaryproject.db.DiariesDatabase
import com.example.mydiaryproject.db.entity.DiaryDb
import java.util.*


class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var diariesDatabase: DiariesDatabase

    private val diaryAdapter by lazy(LazyThreadSafetyMode.NONE) {
        DiariesAdapter(deleteAction = {
            Log.d("TAG", ": ")
        })
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)


        initialize()

        setSupportActionBar(binding.toolbar)
        getDairyList()
    }

    private fun initialize() {
        diariesDatabase = DiariesDatabase.invoke(applicationContext)

        binding.dairyRecyclerView.apply {
            adapter = diaryAdapter
            setHasFixedSize(true)
        }

        binding.addDiary.setOnClickListener {
            val intent = Intent(this, AddDiaryActivity::class.java)
            startActivity(intent)
        }
        AsyncTask.execute {
            diariesDatabase.dairyDao().insertDiary(
                DiaryDb( Calendar.getInstance().time.toString(),"binding.name.text.toString()","","binding.password.text.toString()", "binding.description.text.toString()", "GOOD")
            )
        }
    }

    private fun getDairyList() {
            AsyncTask.execute {
              diaryAdapter.setItems(diariesDatabase.dairyDao().getDiaryList())
            }
    }
}

